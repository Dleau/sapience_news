from tensorflow_hub import load
import pickle

print('Loading universal sentence encoder (this may take a couple of minutes)')
SENTENCE_ENCODER = load("https://tfhub.dev/google/universal-sentence-encoder-large/5")
print('Success')

print('Loading bias and factualness classifiers')
FACT = pickle.load(open('X_fact_model', 'rb'))
BIAS = pickle.load(open('X_bias_model', 'rb'))
print('Success! All models loaded into RAM')