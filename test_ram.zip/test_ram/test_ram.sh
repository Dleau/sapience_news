pip3 install virtualenv &&
virtualenv venv &&
source ./venv/bin/activate &&
pip3 install tensorflow_hub &&
pip3 install absl-py &&
pip3 install tensorflow &&
pip3 install sklearn &&
python3 load_models.py &&
deactivate