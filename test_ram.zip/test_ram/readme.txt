First, run this:
$ chmod +x test_ram.sh

Then, run this:
$ ./test_ram.sh

If you see "Success! All models loaded into RAM",
at the end of execution, we can likely run the API
on this Pi.

You can delete these files and the venv/ directory
after the test has concluded.
